================================================================================
SupeRR Selector S2 Round 1: Reproducibility Bundle (Version 2)
Methodology: "Identify the Most Reliable Players Under Pressure"
================================================================================

This bundle contains the complete, rigorous, and fully reproducible pipeline
for the Rajasthan Royals SupeRR Selector Season 2 (Round 1) submission.

PREREQUISITES:
- Python 3.9+
- Libraries: pandas, numpy, scikit-learn, matplotlib, reportlab, pypdf

DATA PACK LOCATION:
Place the competition CSVs (ball_by_ball.csv, matches.csv, competitions.csv,
teams.csv, playing_eleven.csv, competition_team_player_mapping.csv) in your
chosen data directory and point the `U` path in `prep.py` accordingly.

PIPELINE EXECUTION ORDER:
--------------------------------------------------------------------------------
1. python code/prep.py
   Cleans raw deliveries: removes super overs (innings > 2), revised-target /
   DLS matches, and no-result matches. Standardizes runs off bat vs extras,
   credits dismissals, and extracts ball-by-ball match state.
   Output: 195,124 total deliveries across 818 matches (186,814 legal balls).

2. python code/wp.py
   Trains match-grouped 5-fold cross-validated Gradient Boosting win-probability
   models (out-of-fold predictions only).
   Outputs:
   - Innings 1: AUC = 0.6805, Log-loss = 0.6445 (vs 0.6931 naive baseline)
   - Innings 2: AUC = 0.8915, Log-loss = 0.4127 (vs 0.6919 naive baseline)

3. python code/values.py
   Calculates Leverage Index (LI) via state win-probability differences weighted
   by empirical outcome frequency. Computes expected runs/dismissals and expected
   wicket cost W(balls_left, wickets_lost).

4. python code/agg.py
   Identifies pressure deliveries (LI >= 1.5, 0.15 <= WP <= 0.85, legal balls >= 18).
   Total pressure balls: 26,520 (14.2% of legal balls).
   Applies competition tier weights (IPL = 1.0, Full Member T20I = 0.8, Associate/Emerging = 0.4).
   Saves: balls_final.pkl.

5. python code/reliability.py
   Performs 40-split match-level random split-half cross-validation to assess
   the predictive reliability of pressure performance vs ordinary baseline.
   Saves: results/reliability_summary.csv.

6. python code/final_model.py
   Computes Empirical-Bayes shrinkage estimates for pressure batting and bowling
   value, shrinkage toward player baseline, and consistency metrics.

7. python code/ensemble.py
   Evaluates 9 model specifications across weightings and shrinkage priors,
   alongside 100 match-level bootstrap iterations to quantify rank stability.

8. python code/finalize.py
   Applies eligibility criteria (>= 90 pressure balls, >= 10 pressure spells/inns,
   >= 40 IPL pressure balls, and active in IPL 2026: >= 30 balls faced / >= 24 balls bowled).
   Outputs: results/final_bat_filtered.csv, results/final_bowl_filtered.csv, trad_*.csv.

9. python code/build_rigorous_pdf.py
   Compiles the complete 16-page landscape PDF report (RR_AuctionStrategy_Rigorous.pdf)
   with all tables, charts, dynamic page numbering, and zero placeholder text.

10. python code/verify_report.py
    Automated verification suite checking zero forbidden words, exact top-10 orders,
    exact delivery counts, WP diagnostics, split-half correlations, and table labels.
    Exit code 0 on full verification pass.

RESULTS DIRECTORY CONTENTS:
- final_bat_filtered.csv: Top-ranked batters under pressure with ensemble & bootstrap metrics.
- final_bowl_filtered.csv: Top-ranked bowlers under pressure with ensemble & bootstrap metrics.
- trad_bat.csv: Traditional pressure stats (SR, Dot %, Boundary %, RPI) for top batters.
- trad_bowl.csv: Traditional pressure stats (Economy, Dot %, Bowling avg) for top bowlers.
- league_pressure.csv: League-wide pressure vs ordinary situation validation metrics.
- reliability_summary.csv: 40-split split-half correlation coefficients.
================================================================================
