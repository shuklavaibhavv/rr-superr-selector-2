import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
import io,contextlib
with contextlib.redirect_stdout(io.StringIO()):
    from final_model import compute, b0
    from agg import pressure
KW=dict(minb=90,minm=10)
specs={}
def mk(name,b,**kw): specs[name]=(b,kw)
mk('base',b0)
for nm,k in {'LI1.25':dict(li=1.25),'LI2.0':dict(li=2.0),'nogate':dict(live=(0,1))}.items():
    b=b0.copy(); b['press']=pressure(b,**k); mk(nm,b)
b=b0.copy(); b['w']=1.0; mk('equalw',b)
b=b0.copy(); b['press']=b.press&(b.innings==2); mk('chase',b,minb=60,minm=8)
mk('clutch30',b0,w_cons=.3,w_delta=.3)
mk('noclutch',b0,w_cons=0,w_delta=0)
b=b0[b0.match_format=='T20'].copy(); mk('IPL',b,minb=60,minm=8)
res={r:{} for r in ('bat','bowl')}
base_tbl={}
for r in res:
    for nm,(b,kw) in specs.items():
        k=dict(KW); k.update(kw)
        el=compute(b,r,**k); res[r][nm]=el.set_index('name').score
        if nm=='base': base_tbl[r]=el
# bootstrap bagging of base spec
mids=b0.match_id.unique(); rng=np.random.RandomState(21); B=100
boots={r:[] for r in res}
for i in range(B):
    draw=pd.Series(rng.choice(mids,len(mids))).value_counts()
    cnt=b0.match_id.map(draw).fillna(0).astype(int).values
    idx=np.repeat(np.arange(len(b0)),cnt)
    cp=np.concatenate([np.arange(c) for c in cnt[cnt>0][:0]]) if False else None
    b=b0.iloc[idx].copy()
    # unique copy id so duplicated matches stay separate innings
    b['_k']=b.groupby(level=0).cumcount() if False else 0
    ccount=draw.reindex(b0.match_id.unique()).fillna(0).astype(int)
    copy_id=np.concatenate([np.repeat(np.arange(c),1) for c in []]) if False else None
    b=pd.concat([b0[b0.match_id.map(draw)>=j].assign(match_id=lambda x:x.match_id*100+j) for j in range(1,int(draw.max())+1)],ignore_index=True)
    for r in res: boots[r].append(compute(b,r,**KW).set_index('name').score)
out={}
for r in res:
    S=pd.DataFrame(res[r]); Bm=pd.DataFrame(boots[r]).T
    d=pd.DataFrame({'spec_mean':S.mean(axis=1),'spec_min':S.min(axis=1),'spec_top10':(S.rank(ascending=False)<=10).sum(axis=1),
                    'boot_mean':Bm.mean(axis=1),'boot_top10':(Bm.rank(ascending=False)<=10).sum(axis=1)/B,'boot_n':Bm.notna().sum(axis=1)/B})
    bt=base_tbl[r].set_index('name')
    d=d[d.index.isin(bt.index)].copy()
    d['ensemble']=0.5*d.spec_mean+0.5*d.boot_mean
    d=d.join(bt[['p_n','ipl_pn','t20i_pn','matches','pv_raw','pv_post','base','delta','cons','score','rank']])
    d=d.sort_values('ensemble',ascending=False); d['final_rank']=np.arange(1,len(d)+1)
    d.to_csv(f'final_{r}.csv'); out[r]=d
    print('=====',r); print(d.head(14)[['ensemble','spec_top10','boot_top10','p_n','pv_raw','pv_post','delta','cons','rank']].round(2).to_string())
