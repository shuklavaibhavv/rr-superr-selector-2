import pandas as pd, numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier as HGC, HistGradientBoostingRegressor as HGR
from sklearn.model_selection import GroupKFold
from sklearn.metrics import log_loss, roc_auc_score
b=pd.read_pickle('balls_raw.pkl')

def feats(inn,bl,w,runs,target):
    bl=np.asarray(bl,float); w=np.asarray(w,float); runs=np.asarray(runs,float)
    played=120-bl
    crr=np.where(played>0,runs/np.maximum(played,1)*6,0)
    if inn==1:
        proj=runs+ (bl*0)  # placeholder
        return np.c_[bl,w,runs]
    need=np.asarray(target,float)-runs
    rrr=np.where(bl>0,need/np.maximum(bl,1)*6,99)
    return np.c_[bl,w,need,np.clip(rrr,0,40)]

# ---------- training states (before states + terminal state)
def state_rows(df):
    out=[]
    last=df.groupby(['match_id','innings']).tail(1)
    for inn in (1,2):
        d=df[df.innings==inn]
        X=feats(inn,d.bl,d.wkts_before,d.runs_before,d.target)
        y=d.bat_win.values; gid=d.match_id.values
        l=last[last.innings==inn]
        bl2=l.bl-l.legal.astype(int); w2=l.wkts_before+l.wkt; r2=l.runs_before+l.team_runs
        X2=feats(inn,bl2,w2,r2,l.target)
        out.append((inn,np.r_[X,X2],np.r_[y,l.bat_win.values],np.r_[gid,l.match_id.values]))
    return out

folds=GroupKFold(n_splits=5)
mids=b.match_id.unique(); rng=np.random.RandomState(7); rng.shuffle(mids)
fold_of={m:i%5 for i,m in enumerate(mids)}
b['fold']=b.match_id.map(fold_of)
models={}
for inn,X,y,gid in state_rows(b):
    f=np.array([fold_of[g] for g in gid])
    for k in range(5):
        clf=HGC(max_iter=250,learning_rate=0.06,max_leaf_nodes=15,min_samples_leaf=100,l2_regularization=1.0,random_state=0)
        clf.fit(X[f!=k],y[f!=k]); models[(inn,k)]=clf
    p=np.zeros(len(y))
    for k in range(5): p[f==k]=models[(inn,k)].predict_proba(X[f==k])[:,1]
    print('innings',inn,'OOF logloss',round(log_loss(y,p),4),'AUC',round(roc_auc_score(y,p),4),'base',round(log_loss(y,np.full(len(y),y.mean())),4))
import pickle; pickle.dump(models,open('wp_models.pkl','wb'))
b.to_pickle('balls_fold.pkl')
