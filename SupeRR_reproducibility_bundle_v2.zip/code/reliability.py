"""
reliability.py - Split-half reliability analysis for pressure vs ordinary form.
Procedure: 40 random splits of MATCHES into two halves.
For each player with >= 20 balls in each half, compute:
1. Batting value (total run value / 100 balls): pressure A vs pressure B, ordinary A vs pressure B
2. Bowling economy component: pressure A vs pressure B, ordinary A vs pressure B
3. Bowling wicket component: pressure A vs pressure B, ordinary A vs pressure B
"""
import pandas as pd
import numpy as np

def run_reliability(pkl_path='balls_final.pkl', n_splits=40, min_balls=20, seed=42):
    b = pd.read_pickle(pkl_path)
    
    # Components
    b['bat_c1'] = b.runs - b.E_batruns
    b['bat_c2'] = -b.wk_cost * (b.bat_out - b.E_batout)
    b['bat_tot'] = (b['bat_c1'] + b['bat_c2']) * 100.0  # per 100 balls
    b['bat_run'] = b['bat_c1'] * 100.0
    
    b['bowl_c1'] = -(b.conceded - b.E_conc) * 100.0
    b['bowl_c2'] = b.wk_cost * (b.bowl_wkt - b.E_bwk) * 100.0
    
    mids = b.match_id.unique()
    rng = np.random.RandomState(seed)
    
    corrs = {
        'bat_tot_pp': [], 'bat_tot_op': [], 'bat_run_pp': [], 'bat_run_op': [],
        'bowl_c1_pp': [], 'bowl_c1_op': [],
        'bowl_c2_pp': [], 'bowl_c2_op': [],
        'n_bat': [], 'n_bowl': []
    }
    
    for _ in range(n_splits):
        shuf = mids.copy()
        rng.shuffle(shuf)
        h1 = set(shuf[:len(shuf)//2])
        
        # Batting: non-wide balls
        db = b[~b.wide]
        bA = db[db.match_id.isin(h1)]
        bB = db[~db.match_id.isin(h1)]
        
        pA = bA[bA.press].groupby('striker_id')['bat_tot'].agg(['mean','count'])
        pB = bB[bB.press].groupby('striker_id')['bat_tot'].agg(['mean','count'])
        qA = bA[~bA.press].groupby('striker_id')['bat_tot'].agg(['mean','count'])
        
        pA_run = bA[bA.press].groupby('striker_id')['bat_run'].agg(['mean','count'])
        pB_run = bB[bB.press].groupby('striker_id')['bat_run'].agg(['mean','count'])
        qA_run = bA[~bA.press].groupby('striker_id')['bat_run'].agg(['mean','count'])
        
        ok_bat = (pA['count'] >= min_balls) & (pB['count'] >= min_balls) & (qA['count'] >= min_balls)
        idx_b = ok_bat[ok_bat].index
        corrs['n_bat'].append(len(idx_b))
        if len(idx_b) > 5:
            corrs['bat_tot_pp'].append(np.corrcoef(pA.loc[idx_b, 'mean'], pB.loc[idx_b, 'mean'])[0, 1])
            corrs['bat_tot_op'].append(np.corrcoef(qA.loc[idx_b, 'mean'], pB.loc[idx_b, 'mean'])[0, 1])
            corrs['bat_run_pp'].append(np.corrcoef(pA_run.loc[idx_b, 'mean'], pB_run.loc[idx_b, 'mean'])[0, 1])
            corrs['bat_run_op'].append(np.corrcoef(qA_run.loc[idx_b, 'mean'], pB_run.loc[idx_b, 'mean'])[0, 1])
            
        # Bowling: all balls
        bwA = b[b.match_id.isin(h1)]
        bwB = b[~b.match_id.isin(h1)]
        
        pA_c1 = bwA[bwA.press].groupby('bowler_id')['bowl_c1'].agg(['mean','count'])
        pB_c1 = bwB[bwB.press].groupby('bowler_id')['bowl_c1'].agg(['mean','count'])
        qA_c1 = bwA[~bwA.press].groupby('bowler_id')['bowl_c1'].agg(['mean','count'])
        
        pA_c2 = bwA[bwA.press].groupby('bowler_id')['bowl_c2'].agg(['mean','count'])
        pB_c2 = bwB[bwB.press].groupby('bowler_id')['bowl_c2'].agg(['mean','count'])
        qA_c2 = bwA[~bwA.press].groupby('bowler_id')['bowl_c2'].agg(['mean','count'])
        
        ok_bw = (pA_c1['count'] >= min_balls) & (pB_c1['count'] >= min_balls) & (qA_c1['count'] >= min_balls)
        idx_w = ok_bw[ok_bw].index
        corrs['n_bowl'].append(len(idx_w))
        if len(idx_w) > 5:
            corrs['bowl_c1_pp'].append(np.corrcoef(pA_c1.loc[idx_w, 'mean'], pB_c1.loc[idx_w, 'mean'])[0, 1])
            corrs['bowl_c1_op'].append(np.corrcoef(qA_c1.loc[idx_w, 'mean'], pB_c1.loc[idx_w, 'mean'])[0, 1])
            corrs['bowl_c2_pp'].append(np.corrcoef(pA_c2.loc[idx_w, 'mean'], pB_c2.loc[idx_w, 'mean'])[0, 1])
            corrs['bowl_c2_op'].append(np.corrcoef(qA_c2.loc[idx_w, 'mean'], pB_c2.loc[idx_w, 'mean'])[0, 1])
            
    summary = pd.DataFrame([
        {
            'Metric Component': 'Batting value (total run value / 100b)',
            'Pressure A vs Pressure B': round(np.mean(corrs['bat_tot_pp']), 2),
            'Ordinary A vs Pressure B': round(np.mean(corrs['bat_tot_op']), 2),
            'Mean N Players': int(round(np.mean(corrs['n_bat'])))
        },
        {
            'Metric Component': 'Bowling economy component',
            'Pressure A vs Pressure B': round(np.mean(corrs['bowl_c1_pp']), 2),
            'Ordinary A vs Pressure B': round(np.mean(corrs['bowl_c1_op']), 2),
            'Mean N Players': int(round(np.mean(corrs['n_bowl'])))
        },
        {
            'Metric Component': 'Bowling wicket component',
            'Pressure A vs Pressure B': round(np.mean(corrs['bowl_c2_pp']), 2),
            'Ordinary A vs Pressure B': round(np.mean(corrs['bowl_c2_op']), 2),
            'Mean N Players': int(round(np.mean(corrs['n_bowl'])))
        }
    ])
    return summary

if __name__ == '__main__':
    res = run_reliability('/tmp/run_pipeline/balls_final.pkl')
    print(res.to_string(index=False))
    res.to_csv('reliability_summary.csv', index=False)
