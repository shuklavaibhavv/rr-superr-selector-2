import pandas as pd, numpy as np
b0=pd.read_pickle('balls_final.pkl')
b0['bat_c1']=b0.runs-b0.E_batruns; b0['bat_c2']=-b0.wk_cost*(b0.bat_out-b0.E_batout)
b0['bowl_c1']=-(b0.conceded-b0.E_conc); b0['bowl_c2']=b0.wk_cost*(b0.bowl_wkt-b0.E_bwk)
ROLE={'bat':('striker_id','striker_name','bat_c1','bat_c2'),'bowl':('bowler_id','bowler_name','bowl_c1','bowl_c2')}
def wmean(df,pid,cols):
    d=df[[pid,'w']+cols].copy()
    for c in cols: d[c]=d[c]*d.w
    s=d.groupby(pid).sum(); n=df.groupby(pid).size()
    out=s[cols].div(s.w,axis=0)*100; out['n']=n; out['wn']=s.w; return out
def eb_prior(m,n,s2,minn=60):
    ok=n>=minn; mu=np.average(m[ok],weights=n[ok])
    t2=max(np.average((m[ok]-mu)**2,weights=n[ok])-np.average(s2[ok]/n[ok],weights=n[ok]),1e-9); return mu,t2
def compute(b,role,pcol='press',minb=100,minm=12,min_ipl=40,w_cons=0.15,w_delta=0.15,floor_frac=0.25,return_all=False):
    pid,pn,c1,c2=ROLE[role]
    d=b[~b.wide] if role=='bat' else b
    P=d[d[pcol]]; Q=d[~d[pcol]]
    cols=[c1,c2]; tot=pd.DataFrame(index=sorted(d[pid].unique()))
    post={}; base={}
    for c in cols:
        mp=wmean(P,pid,[c]); mq=wmean(Q,pid,[c]) if c==c1 else wmean(d,pid,[c])
        s2p=np.average((P[c]*100-np.average(P[c]*100,weights=P.w))**2,weights=P.w)
        s2q=np.average((Q[c]*100-np.average(Q[c]*100,weights=Q.w))**2,weights=Q.w)
        # baseline: shrunk non-pressure value
        mq=mq.reindex(tot.index); mp=mp.reindex(tot.index)
        okq=mq.wn.fillna(0)>=60
        muq,t2q=eb_prior(mq[c][okq].values,mq.wn[okq].values,np.full(okq.sum(),s2q))
        lam_q=t2q/(t2q+s2q/mq.wn.fillna(1e-9))
        qs=(muq+lam_q*(mq[c].fillna(muq)-muq))
        # prior for pressure: regress on baseline
        okp=(mp.wn.fillna(0)>=40)&okq.reindex(tot.index).fillna(False)
        x=qs[okp].values; y=mp[c][okp].values; wts=mp.wn[okp].values
        if c==c1:
            A=np.c_[np.ones(len(x)),x]; W=np.diag(wts)
            beta=np.linalg.solve(A.T@W@A,A.T@W@y); beta[1]=np.clip(beta[1],0,1.5)
            a0=np.average(y-beta[1]*x,weights=wts)
        else:   # wicket component: skill assumed not pressure-specific -> prior = all-ball skill
            beta=np.array([0.,1.]); a0=0.0
        resid=y-(a0+beta[1]*x)
        t2r=np.average(resid**2,weights=wts)-np.average(s2p/wts,weights=wts)
        _,t2raw=eb_prior(mp[c][okp].values,wts,np.full(len(wts),s2p),minn=0)
        t2r=max(t2r,floor_frac*t2raw)
        prior=a0+beta[1]*qs
        lam=t2r/(t2r+s2p/mp.wn.fillna(1e-9))
        post[c]=prior+lam*(mp[c].fillna(prior)-prior); base[c]=qs
        tot[c+'_raw']=mp[c]; tot[c+'_post']=post[c]
        tot[c+'_lam']=lam; tot[c+'_beta']=beta[1]; tot[c+'_t2r']=t2r
    tot['p_n']=P.groupby(pid).size(); tot['p_wn']=P.groupby(pid).w.sum()
    tot['name']=d.groupby(pid)[pn].agg(lambda s:s.mode().iat[0])
    ip=P[P.match_format=='T20']; tot['ipl_pn']=ip.groupby(pid).size(); tot['t20i_pn']=P[P.match_format=='T20I'].groupby(pid).size()
    tot[['ipl_pn','t20i_pn']]=tot[['ipl_pn','t20i_pn']].fillna(0)
    tot['pv_raw']=tot[c1+'_raw'].fillna(0)+tot[c2+'_raw'].fillna(0)
    tot['pv_post']=post[c1]+post[c2]; tot['base']=base[c1]+base[c2]
    tot['delta']=tot.pv_post-tot.base
    # match-level consistency on total value
    P=P.assign(tv=(P[c1]+P[c2])*P.w)
    pm=P.groupby([pid,'match_id','innings']).agg(n=('tv','size'),s=('tv','sum')).reset_index()
    pm=pm[pm.n>=(6 if role=='bowl' else 4)]; pm['hit']=(pm.s>0).astype(int)
    tot['matches']=pm.groupby(pid).size(); tot['hits']=pm.groupby(pid).hit.sum(); tot[['matches','hits']]=tot[['matches','hits']].fillna(0)
    tot['hit_raw']=tot.hits/tot.matches.replace(0,np.nan)
    p0=tot.hits.sum()/tot.matches.sum(); tot['cons']=(tot.hits+10*p0)/(tot.matches+10)
    el=tot[(tot.p_n>=minb)&(tot.matches>=minm)&(tot.ipl_pn>=min_ipl)].copy()
    z=lambda s:(s-s.mean())/s.std()
    el['z_value']=z(el.pv_post); el['z_cons']=z(el.cons); el['z_delta']=z(el.delta)
    el['score']=(1-w_cons-w_delta)*el.z_value+w_cons*el.z_cons+w_delta*el.z_delta
    el=el.sort_values('score',ascending=False); el['rank']=np.arange(1,len(el)+1)
    return (el,tot) if return_all else el
if __name__=='__main__':
    pd.set_option('display.width',250)
    for role in ('bat','bowl'):
        el,tot=compute(b0,role,return_all=True)
        c1,c2=ROLE[role][2:]
        print(role,'eligible',len(el),'| lambda_c1 mean',el[c1+'_lam'].mean().round(3),'lambda_c2',el[c2+'_lam'].mean().round(3),'beta',el[c1+'_beta'].iat[0].round(2),el[c2+'_beta'].iat[0].round(2))
        print(el[['name','p_n','ipl_pn','t20i_pn','matches','pv_raw','pv_post','base','delta','cons','score']].head(15).round(2).to_string())
