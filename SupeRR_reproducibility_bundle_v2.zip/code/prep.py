import pandas as pd, numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier as HGC, HistGradientBoostingRegressor as HGR
from sklearn.model_selection import GroupKFold
U='/tmp/data_pack/'
b=pd.read_csv(U+'ball_by_ball.csv'); m=pd.read_csv(U+'matches.csv'); c=pd.read_csv(U+'competitions.csv')
m=m.merge(c[['comp_id','comp_name','match_format','season']],on='comp_id')

# ---- cleaning / eligibility of matches
dls=m.revised_target.notna()|m.first_inn_revised_overs.notna()|m.second_inn_revised_overs.notna()
ok=m[~dls & m.win_team_id.notna()][['match_id','win_team_id','match_format','comp_name','match_date','venue_id']]
b=b[(b.innings<=2)].merge(ok,on='match_id')
b=b.sort_values(['match_id','innings','innings_ball_num']).reset_index(drop=True)
et=b.extras_type.fillna('')
b['wide']=(et=='wide'); b['noball']=et.isin(['Overstep','other'])
b['legal']=~(b.wide|b.noball)
b['team_runs']=b.runs+b.extras1_runs+b.extras_2_runs
b['bye']=et.isin(['byes','legbyes'])
b['bye_runs']=np.where(b.bye,b.extras1_runs+b.extras_2_runs,0)
b['wkt']=b.is_wicket.astype(int)
b['bat_out']=(b.is_wicket&(b.dismissed_player_id==b.striker_id)).astype(int)
bw=['Caught','Bowled','LBW','Stump','Hit Wicket']
b['bowl_wkt']=(b.is_wicket&b.dismissal_type.isin(bw)).astype(int)
g=b.groupby(['match_id','innings'])
b['runs_before']=g.team_runs.cumsum()-b.team_runs
b['wkts_before']=g.wkt.cumsum()-b.wkt
b['legal_before']=g.legal.cumsum()-b.legal.astype(int)
b['bl']=120-b.legal_before
tot1=b[b.innings==1].groupby('match_id').team_runs.sum().rename('tot1')
b=b.merge(tot1,on='match_id')
b['target']=b.tot1+1
b['bat_first_win']=None
# did batting team win
b['bat_win']=(b.batting_team_id==b.win_team_id).astype(int)
b=b[b.bl>0]   # drop deliveries beyond 120 legal (none expected)
b['need']=np.where(b.innings==2,b.target-b.runs_before,np.nan)
b.to_pickle('balls_raw.pkl')
print(len(b), b.match_id.nunique())
print(b.groupby('innings').bat_win.mean())
