import pandas as pd, numpy as np, pickle
from sklearn.ensemble import HistGradientBoostingRegressor as HGR
exec(open('wp.py').read().split('# ---------- training states')[0].split("b=pd.read_pickle('balls_raw.pkl')")[1]) if False else None
b=pd.read_pickle('balls_fold.pkl'); models=pickle.load(open('wp_models.pkl','rb'))
def feats(inn,bl,w,runs,target):
    bl=np.asarray(bl,float); w=np.asarray(w,float); runs=np.asarray(runs,float)
    played=120-bl; crr=np.where(played>0,runs/np.maximum(played,1)*6,0)
    if inn==1: return np.c_[bl,w,runs]
    need=np.asarray(target,float)-runs; rrr=np.where(bl>0,need/np.maximum(bl,1)*6,99)
    return np.c_[bl,w,need,np.clip(rrr,0,40)]
def wp(df,bl,w,runs):
    """win prob for batting team given hypothetical after-state arrays aligned with df"""
    out=np.zeros(len(df)); bl=np.asarray(bl); w=np.asarray(w); runs=np.asarray(runs)
    for inn in (1,2):
        for k in range(5):
            idx=np.where((df.innings.values==inn)&(df.fold.values==k))[0]
            if len(idx)==0: continue
            X=feats(inn,bl[idx],w[idx],runs[idx],df.target.values[idx])
            out[idx]=models[(inn,k)].predict_proba(X)[:,1]
    i2=np.where(df.innings.values==2)[0]
    need=df.target.values[i2]-runs[i2]
    win=need<=0; lose=(~win)&((w[i2]>=10)|(bl[i2]<=0))
    out[i2[win]]=1.0; out[i2[lose]]=0.0
    return out
# ---- before-state WP
bl0=b.bl.values; w0=b.wkts_before.values; r0=b.runs_before.values
b['wp0']=wp(b,bl0,w0,r0)
leg=b.legal.values.astype(int)
bl1=bl0-leg
# actual after, batter view, bowler view
b['wp_act']=wp(b,bl1,w0+b.wkt.values,r0+b.team_runs.values)
b['wp_bat']=wp(b,bl1,w0+b.bat_out.values,r0+b.runs.values)
b['wp_bowl']=wp(b,bl1,w0+b.bowl_wkt.values,r0+b.team_runs.values-b.bye_runs.values)
# ---- leverage: outcome distribution by (innings, phase, wickets bucket)
b['over']=(120-b.bl)//6   # 0..19 over of innings by legal balls
b['phase']=pd.cut(b.over,[-1,5,14,19],labels=['PP','Mid','Death']).astype(str)
b['wb']=np.minimum(b.wkts_before,6)//2
L=b[b.legal]
outs=[0,1,2,3,4,6]
def oc(r): return np.select([r>=6,r==5,r==4,r==3,r==2,r==1],[6,4,4,3,2,1],0)
L=L.assign(oc=np.where(L.wkt==1,-1,oc(L.team_runs.values)))
probs=L.groupby(['innings','phase','wb']).oc.value_counts(normalize=True).unstack(fill_value=0)
key=list(zip(b.innings,b.phase,b.wb))
P=probs.reindex(key).fillna(probs.mean()).values   # columns -1,0,1,2,3,4,6
cols=list(probs.columns)
LI=np.zeros(len(b))
for j,o in enumerate(cols):
    if o==-1: wpo=wp(b,bl1,w0+1,r0)
    else: wpo=wp(b,bl1,w0,r0+o)
    LI+=P[:,j]*np.abs(wpo-b.wp0.values)
b['LI_raw']=LI
b['LI']=b.LI_raw/b.loc[b.legal,'LI_raw'].mean()
# ---- resource table (innings 1 expected additional runs) -> wicket cost
d1=b[b.innings==1]; fin=d1.groupby('match_id').team_runs.sum()
y=d1.match_id.map(fin).values-d1.runs_before.values
Rm=HGR(max_iter=200,learning_rate=0.06,max_leaf_nodes=12,min_samples_leaf=200,random_state=0).fit(d1[['bl','wkts_before']].values,y)
def R(bl,w): 
    bl=np.asarray(bl); w=np.asarray(w)
    r=Rm.predict(np.c_[np.maximum(bl,0),np.minimum(w,9)]); r=np.where((w>=10)|(bl<=0),0,r); return r
b['wk_cost']=R(bl1,w0)-R(bl1,w0+1)
b['wk_cost']=b.wk_cost.clip(lower=3)
print(b.groupby('phase').wk_cost.mean())
# ---- expected outcomes by state (OOF)
def X_state(df):
    return np.vstack([ feats(inn,df.bl[df.innings==inn],df.wkts_before[df.innings==inn],df.runs_before[df.innings==inn],df.target[df.innings==inn]) if False else np.zeros((0,1)) for inn in ()]) if False else None
b['conceded']=b.team_runs-b.bye_runs
def oof_expect(target_col,mask):
    res=np.full(len(b),np.nan)
    for inn in (1,2):
        for k in range(5):
            tr=np.where(mask&(b.innings.values==inn)&(b.fold.values!=k))[0]
            te=np.where(mask&(b.innings.values==inn)&(b.fold.values==k))[0]
            Xa=feats(inn,b.bl.values[tr],b.wkts_before.values[tr],b.runs_before.values[tr],b.target.values[tr])
            Xb=feats(inn,b.bl.values[te],b.wkts_before.values[te],b.runs_before.values[te],b.target.values[te])
            mdl=HGR(max_iter=150,learning_rate=0.05,max_leaf_nodes=12,min_samples_leaf=300,random_state=0).fit(Xa,b[target_col].values[tr])
            res[te]=mdl.predict(Xb)
    return res
nw=~b.wide.values
b['E_batruns']=oof_expect('runs',nw); b['E_batout']=oof_expect('bat_out',nw)
allm=np.ones(len(b),bool)
b['E_conc']=oof_expect('conceded',allm); b['E_bwk']=oof_expect('bowl_wkt',allm)
# WP expectation residuals
b['dwp_bat']=b.wp_bat-b.wp0; b['dwp_bowl']=-(b.wp_bowl-b.wp0)
b['E_dwp_bat']=oof_expect('dwp_bat',nw); b['E_dwp_bowl']=oof_expect('dwp_bowl',allm)
# values
b['v_bat_runs']=(b.runs-b.E_batruns)-b.wk_cost*(b.bat_out-b.E_batout)
b['v_bowl_runs']=-(b.conceded-b.E_conc)+b.wk_cost*(b.bowl_wkt-b.E_bwk)
b['v_bat_wp']=b.dwp_bat-b.E_dwp_bat
b['v_bowl_wp']=b.dwp_bowl-b.E_dwp_bowl
b.to_pickle('balls_val.pkl')
print(b[['LI','wp0']].describe())
print(b[nw][['v_bat_runs','v_bat_wp']].mean(), b[['v_bowl_runs','v_bowl_wp']].mean())
