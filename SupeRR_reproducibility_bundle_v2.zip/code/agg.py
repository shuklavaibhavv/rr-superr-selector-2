import pandas as pd, numpy as np
b=pd.read_pickle('balls_val.pkl')
U='/tmp/data_pack/'
m=pd.read_csv(U+'matches.csv')
FULL={'India','Pakistan','West Indies','New Zealand','Bangladesh','England','Sri Lanka','Australia','South Africa','Zimbabwe','Afghanistan','Ireland'}
mm=m.set_index('match_id')
def wt(r):
    return 1.0
b['home']=b.match_id.map(mm.home_team); b['away']=b.match_id.map(mm.away_team)
isI=b.match_format=='T20I'
full=b.home.isin(FULL)&b.away.isin(FULL)
b['w']=np.where(~isI&b.comp_name.str.startswith('IPL'),1.0,np.where(isI&full,0.8,0.4))
def pressure(df,li=1.5,live=(0.15,0.85),minplayed=18):
    played=120-df.bl
    return (df.LI>=li)&df.wp0.between(*live)&(played>=minplayed)
b['press']=pressure(b)
b.to_pickle('balls_final.pkl')
d=b[b.legal]; print('pressure share',d.press.mean().round(3), d.groupby('innings').press.mean().round(3).to_dict(), d.groupby('phase').press.mean().round(3).to_dict())
print(b.groupby('match_format').w.mean())
