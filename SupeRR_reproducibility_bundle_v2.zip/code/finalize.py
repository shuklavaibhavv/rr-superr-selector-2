import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
b=pd.read_pickle('balls_final.pkl'); av=pd.read_csv('availability.csv')
b26=b[b.comp_name=='IPL 2026']
bf=b26[~b26.wide].groupby('striker_id').size(); bw=b26.groupby('bowler_id').size()
idmap=pd.concat([b[['striker_id','striker_name']].set_axis(['id','name'],axis=1),b[['bowler_id','bowler_name']].set_axis(['id','name'],axis=1)]).drop_duplicates('name')
nm2id=dict(zip(idmap.name,idmap.id))
final={}
for r,minw in (('bat',30),('bowl',24)):
    d=pd.read_csv(f'final_{r}.csv'); d['pid']=d.name.map(nm2id)
    d['ipl26']=d.pid.map(bf if r=='bat' else bw).fillna(0)
    d=d[d.ipl26>=minw].sort_values('ensemble',ascending=False).reset_index(drop=True); d['final_rank']=np.arange(1,len(d)+1)
    final[r]=d; d.to_csv(f'final_{r}_filtered.csv',index=False)
    print(r); print(d.head(12)[['final_rank','name','ensemble','spec_top10','boot_top10','ipl26']].round(2).to_string())
# traditional pressure stats
def trad(r,names):
    rows=[]
    for n in names:
        if r=='bat':
            d=b[(b.striker_name==n)&~b.wide]; P=d[d.press]; Q=d[~d.press]
            def st(x): 
                runs=x.runs.sum(); outs=x.bat_out.sum(); return dict(balls=len(x),runs=runs,sr=runs/len(x)*100,avg=runs/max(outs,1),bnd=(x.runs>=4).mean()*100,dot=(x.runs==0).mean()*100,outs=outs)
        else:
            d=b[b.bowler_name==n]; P=d[d.press]; Q=d[~d.press]
            def st(x):
                lb=x.legal.sum(); c=x.conceded.sum(); w=x.bowl_wkt.sum(); return dict(balls=lb,runs=c,sr=c/max(lb,1)*6,avg=c/max(w,1),bnd=(x.runs>=4).mean()*100,dot=((x.team_runs==0)&x.legal).sum()/max(lb,1)*100,outs=w)
        p=st(P); q=st(Q); rows.append({'name':n,**{'p_'+k:v for k,v in p.items()},**{'q_'+k:v for k,v in q.items()}})
    return pd.DataFrame(rows)
tb=trad('bat',final['bat'].name.head(10)); tw=trad('bowl',final['bowl'].name.head(10))
tb.to_csv('trad_bat.csv',index=False); tw.to_csv('trad_bowl.csv',index=False)
pd.set_option('display.width',250); print(tb.round(1).to_string()); print(tw.round(1).to_string())
# league pressure vs ordinary
d=b[b.legal]
t=d.groupby(['innings',d.press]).agg(n=('runs','size'),rpo=('team_runs',lambda x:x.mean()*6),dot=('team_runs',lambda x:(x==0).mean()*100),bnd=('runs',lambda x:(x>=4).mean()*100),wk=('wkt',lambda x:x.mean()*100),LI=('LI','mean'),wp=('wp0','mean'))
print(t.round(2)); t.to_csv('league_pressure.csv')
print(d.press.mean(), len(b), b.match_id.nunique(), b.groupby('match_format').match_id.nunique().to_dict(), b.comp_name.value_counts().to_dict())
print(d.groupby('phase').press.mean(), d.groupby('innings').press.mean())
